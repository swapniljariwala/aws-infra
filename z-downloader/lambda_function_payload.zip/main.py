## Test file 

def downlaod_handler(event, context):
    print("Inside the handler")
    return {"message": "All looks good"}